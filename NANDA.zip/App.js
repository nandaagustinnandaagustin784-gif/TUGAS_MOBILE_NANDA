
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Alert,
  StatusBar,
} from 'react-native';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState('');

  const handleLogin = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Peringatan', 'Email dan password harus diisi!');
      return;
    }

    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setEmail('');
    setPassword('');
    setSelectedMenu('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />

      {!isLoggedIn ? (
        <View style={styles.card}>
          <Text style={styles.title}>MY APP</Text>
          <Text style={styles.subtitle}>NAMA KAMU</Text>

          <TextInput
            style={styles.input}
            placeholder="INPUT EMAIL"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <TextInput
            style={styles.input}
            placeholder="INPUT PASSWORD"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity
            style={styles.button}
            onPress={handleLogin}
            activeOpacity={0.7}
          >
            <Text style={styles.buttonText}>TOMBOL LOGIN</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.card}>
          <Text style={styles.title}>HOME PAGE</Text>

          <View style={styles.welcomeBox}>
            <Text style={styles.welcome}>
              WELCOME, {email.split('@')[0].toUpperCase()}
            </Text>
          </View>

          <View style={styles.menuContainer}>
            {['MENU 1', 'MENU 2', 'MENU 3', 'MENU 4'].map((menu) => (
              <TouchableOpacity
                key={menu}
                style={[
                  styles.menuButton,
                  selectedMenu === menu && styles.selectedButton,
                ]}
                onPress={() => setSelectedMenu(menu)}
                activeOpacity={0.7}
              >
                <Text style={styles.menuText}>{menu}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {selectedMenu !== '' && (
            <View style={styles.detailBox}>
              <Text style={styles.detailText}>
                Kamu memilih {selectedMenu}
              </Text>
            </View>
          )}

          <TouchableOpacity
            style={styles.logoutButton}
            onPress={handleLogout}
            activeOpacity={0.7}
          >
            <Text style={styles.buttonText}>TOMBOL LOGOUT</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F1F5F9',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    width: '100%',
    maxWidth: 360,
    minHeight: 480,
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: '#334155',
    borderRadius: 8,
    padding: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 23,
    fontWeight: 'bold',
    color: '#1E293B',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 35,
  },
  input: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: '#475569',
    borderRadius: 4,
    paddingHorizontal: 12,
    marginBottom: 15,
    backgroundColor: '#FFFFFF',
  },
  button: {
    width: '100%',
    padding: 14,
    backgroundColor: '#E2E8F0',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 4,
    alignItems: 'center',
    marginTop: 5,
  },
  buttonText: {
    color: '#1E293B',
    fontSize: 13,
    fontWeight: 'bold',
  },
  welcomeBox: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#475569',
    padding: 18,
    marginVertical: 25,
    alignItems: 'center',
  },
  welcome: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#334155',
  },
  menuContainer: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  menuButton: {
    width: '47%',
    minHeight: 55,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#475569',
    borderRadius: 4,
    backgroundColor: '#F8FAFC',
  },
  selectedButton: {
    backgroundColor: '#CBD5E1',
  },
  menuText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  detailBox: {
    width: '100%',
    padding: 12,
    marginTop: 18,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    borderRadius: 4,
  },
  detailText: {
    fontSize: 13,
    color: '#334155',
  },
  logoutButton: {
    marginTop: 28,
    padding: 13,
    minWidth: 150,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 4,
    backgroundColor: '#F8FAFC',
  },
});
